/*
Author: Maahir Kalban
Assignment Number: Assignment 2 part 1
File Name: Kalban-Maahir-eart547-assignment2
Course/Section: CS 5463-002
Due Date: 09/17/2020
Instructor: Dakai Zhu
*/

#include <stdlib.h>
#include "cSum.h"

int cSum(int m, int n){
   int t = m+n;
   return t;
}
