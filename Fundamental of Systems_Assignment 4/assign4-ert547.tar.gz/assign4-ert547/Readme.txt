1. No one collaborated with me on this assignment.

2. The first part is correct. The second part doesnt work as expected.

3. The challenge was to build a simulated Memory Management Unit.

4. To extract and unzip use comand

	tar -xzvf assign4-ert547.tar.gz

5. To Run Program:

make assign4-part1
./assign4-1 part1-sequence


make assign4-part2
./assign4-2 part2-sequence

	
Then the output will be in assign4-part1-output.txt and assign4-part2-output.txt
Page Faults: 3947